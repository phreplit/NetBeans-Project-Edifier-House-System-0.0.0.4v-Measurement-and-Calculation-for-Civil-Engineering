
// Author: PHNO - Tecnólogo | Pós-Graduado
// Data Release: 05/11/2024
// Versão Código: 0.0.0.2v
// Replit: @PHNO, @PHREPLIT
// E-mail: phreplit@gmail.com

// Software: Edifier House - System - 0.0.0.4v - Measurement and Calculation for Civil Engineering, com GUI[interface grafica] e compilacao em ambiente desktop.

package edifier.house.system;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
//import javafx.scene.control.Button;
//import javafx.scene.control.Label;

/**
 *
 * @author Paulo Henrique
 */
    
public class FXMLDocController implements Initializable {
    
    @FXML
    public TextField textfield;
    public TextField textfield1;
    public TextField textfield2;
    public TextField textfield3;
    public TextField textfield4;
    public TextField textfield5; 
    public TextField textfield6;
    public TextField textfield7;
    public TextField textfield8; 
    public TextField textfield9;
    public TextField textfield10;
    public TextField textfield11; 
    public TextField textfield12;
    public TextField textfield13;
    public TextField textfield14; 
    public TextField textfield15;
    public TextField textfield16;
    public TextField textfield17;
    public TextField textfield18;
    public TextField textfield19; 
    public TextField textfield20;
    public TextField textfield21;
    public TextField textfield22; 
    public TextField textfield23;
    public TextField textfield24;
    public TextField textfield25; 
    public TextField textfield26;
    public TextField textfield27;
    public TextField textfield28;
    
    @FXML
    public void reset1(ActionEvent event) {
        textfield.setText("");
        textfield1.setText("");
        textfield2.setText("");
    };
    
    @FXML
    public void reset2(ActionEvent event) {
        textfield3.setText("");
        textfield4.setText("");
        textfield5.setText("");
        textfield6.setText("");
        textfield7.setText("");
    };
    
    @FXML
    public void reset3(ActionEvent event) {
        textfield8.setText("");
        textfield9.setText("");
        textfield10.setText("");
        textfield11.setText("");
        textfield12.setText("");
    };
    
    @FXML
    public void reset4(ActionEvent event) {
        textfield13.setText("");
        textfield14.setText("");
        textfield15.setText("");
        textfield16.setText("");
    };
    
    @FXML
    public void reset5(ActionEvent event) {
        textfield17.setText("");
        textfield18.setText("");
        textfield19.setText("");
        textfield20.setText("");
    };
    
    @FXML
    public void reset6(ActionEvent event) {
        textfield21.setText("");
        textfield22.setText("");
        textfield23.setText("");
        textfield24.setText("");
    };
    
    @FXML
    public void reset7(ActionEvent event) {
        textfield25.setText("");
        textfield26.setText("");
        textfield27.setText("");
        textfield28.setText("");
    };
    
    @FXML
    public void calc_1(ActionEvent event) {
        int mult = Integer.parseInt(textfield.getText())*Integer.parseInt(textfield1.getText());
	textfield2.setText(String.valueOf(mult));
    };
    
    @FXML
    public void calc_2(ActionEvent event) {
        int var2 = 2;
	int mult2 = Integer.parseInt(textfield3.getText())+Integer.parseInt(textfield4.getText());
        int result2 = mult2 * var2;
        textfield5.setText(String.valueOf(result2));
    };
    
    @FXML
    public void calc_3(ActionEvent event) {
        int mult3 = Integer.parseInt(textfield6.getText())*Integer.parseInt(textfield7.getText());
	textfield8.setText(String.valueOf(mult3));
    };
    
    @FXML
    public void calc_4(ActionEvent event) {
        int var3 = 2;
	int mult3 = Integer.parseInt(textfield9.getText())+Integer.parseInt(textfield10.getText());
        int result3 = mult3 * var3;
        textfield11.setText(String.valueOf(result3));
    };
    
    @FXML
    public void calc_5(ActionEvent event) {
        int var4 = 25;
	 int mult4 = Integer.parseInt(textfield12.getText())*Integer.parseInt(textfield13.getText());
	 int result4 = mult4 * var4;
	 textfield14.setText(String.valueOf(mult4));
	 textfield15.setText(String.valueOf(result4));
    };
    
    @FXML
    public void calc_6(ActionEvent event) {
        int var5 = 25;
	int mult5 = Integer.parseInt(textfield16.getText())*Integer.parseInt(textfield17.getText());
	int result5 = mult5 * var5;	             
	textfield18.setText(String.valueOf(mult5));
	textfield19.setText(String.valueOf(result5));
    };
    
    @FXML
    public void calc_7(ActionEvent event) {
        int var6 = 25;
	int mult6 = Integer.parseInt(textfield20.getText())*Integer.parseInt(textfield21.getText());
	int result6 = mult6 * var6;	             
	textfield22.setText(String.valueOf(mult6));
	textfield23.setText(String.valueOf(result6));
    };
    
    @FXML
    public void info(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION); // mudar para Alert.AlertType.CONFIRMATION, duas opcoes OK e CANCEL
        
        alert.setTitle("Info");
        alert.setContentText("\nTo calculate the Land Area [Square Meter] - Regular Size Land [4 equal sides] - we will calculate the width times the length."
+"\nTo calculate the Perimeter of a Land [Meters in Sequence] - Regular Size Land [4 equal sides] - we will add all the sides and obtain the meter in sequence."
+"\nTo calculate the Property Area [Square Meter] - Regular Sized Plot [4 equal sides] - we will calculate the width times the length."
+"\nTo calculate the Property Perimeter [Meters in Sequence] - Regular Sized Plot [4 equal sides] - we will add all the sides and obtain the meter in sequence."
+"\nTo calculate the Area of a Wall [Square Meter] - Regular Size Wall [4 equal sides] - we will calculate the height times the width."
+"\nTo calculate the Area of a Built House [Square Meter] - Regular Size Walls [4 equal sides] - we will calculate the square meters of a wall multiplied by the number of sides of the house."
+"\nTo calculate the Area of a Built Room [Square Meter] - Regular Size Wall [4 equal sides] - we will calculate the square meters of a wall multiplied by the number of sides of the room."
+"\nTo calculate the amount of brickwork blocks to build a wall, we will calculate the square meters of a wall times 25, which is equivalent to one square meter with 25 brickwork blocks.");
        alert.showAndWait();
        
        if(alert.getResult() == ButtonType.OK){
           //
        } // if (alert.getResult() == ButtonType.CANCEL) { 
         // System.exit(0); // ao clicar em cancel, sai da msg de alerta e fecha a aplicação desktop
        //}

    }
    
    @FXML
    public void about(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION); // mudar para Alert.AlertType.CONFIRMATION, duas opcoes OK e CANCEL
        
        alert.setTitle("About");
        alert.setContentText("\nSoftware: Edifier House - Measurement and Calculation for Civil Engineering\n"+"\nAuthor: PHNO"+"\nData Release: 08/11/2024"+"\nVersao Codigo: 0.0.0.2v"+"\nReplit: @PHNO, @PHREPLIT"+"\nE-mail: phreplit@gmail.com");
        alert.showAndWait();
        
        if(alert.getResult() == ButtonType.OK){
           //
        } // if (alert.getResult() == ButtonType.CANCEL) { 
         // System.exit(0); // ao clicar em cancel, sai da msg de alerta e fecha a aplicação desktop
        //}

    }
    
    @FXML
    public void cleardata(ActionEvent event) {
        textfield.setText("");
        textfield1.setText("");
        textfield2.setText("");
        textfield3.setText("");
        textfield4.setText("");
        textfield5.setText(""); 
        textfield6.setText("");
        textfield7.setText("");
        textfield8.setText(""); 
        textfield9.setText("");
        textfield10.setText("");
        textfield11.setText(""); 
        textfield12.setText("");
        textfield13.setText("");
        textfield14.setText(""); 
        textfield15.setText("");
        textfield16.setText("");
        textfield17.setText("");
        textfield18.setText("");
        textfield19.setText(""); 
        textfield20.setText("");
        textfield21.setText("");
        textfield22.setText(""); 
        textfield23.setText("");
        textfield24.setText("");
        textfield25.setText(""); 
        textfield26.setText("");
        textfield27.setText("");
        textfield28.setText("");
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
